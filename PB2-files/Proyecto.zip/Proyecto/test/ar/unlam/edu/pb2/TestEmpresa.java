package ar.unlam.edu.pb2;

import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.List;
import java.util.Set;

import org.junit.Test;

public class TestEmpresa {

	@Test
	public void queSePuedaAgregarUnEmpleado() throws NoExisteLaGeneracionException {
		Empresa empresa = new Empresa("Aerolineas Argentinas");
		//Obtener generacion de la empresa
		Generacion generacion = empresa.buscarGeneracionPorID(1);
		Empleado empleado = new Empleado(1, "Pablo Rocha", LocalDate.of(2008, 11, 24), Rol.PILOTO, generacion);
		
		empresa.agregarEmpleado(empleado);
		
		Integer valorEsperado = 1;
		Integer valorObtenido = empresa.cantidadEmpleados();
		
		assertEquals(valorEsperado, valorObtenido);
	}
	
	@Test
	public void queSePuedaObtenerUnaListaDeEmpleadosOrdenadosPorID() throws NoExisteLaGeneracionException {
		Empresa empresa = new Empresa("Aerolineas Argentinas");
		
		//Obtener generacion de la empresa
		Generacion g1 = empresa.buscarGeneracionPorID(1);
		Generacion g2 = empresa.buscarGeneracionPorID(2);
		Generacion g3 = empresa.buscarGeneracionPorID(3);
		
		Empleado empleado1 = new Empleado(123, "Maggie Simpson", LocalDate.of(2008, 11, 24), Rol.PILOTO, g1);
		Empleado empleado2 = new Empleado(212, "Homer Simpson", LocalDate.of(2012, 9, 12), Rol.AZAFATA, g2);
		Empleado empleado3 = new Empleado(333, "Marge Simpson", LocalDate.of(2010, 4, 2), Rol.PILOTO, g3);
		Empleado empleado4 = new Empleado(441, "Lisa Simpson", LocalDate.of(2003, 11, 22), Rol.AZAFATA, g1);
		Empleado empleado5 = new Empleado(15, "Bart Simpson", LocalDate.of(2015, 8, 20), Rol.PILOTO, g3);
		
		empresa.agregarEmpleado(empleado1);
		empresa.agregarEmpleado(empleado2);
		empresa.agregarEmpleado(empleado3);
		empresa.agregarEmpleado(empleado4);
		empresa.agregarEmpleado(empleado5);
		
		Set<Empleado> empleadosOrdenados =  empresa.obtenerEmpleadosOrdenadosPorId();
		
		for (Empleado empleado : empleadosOrdenados) {
			System.out.println(empleado.getId());
		}
		
	}
	
	@Test
	public void queSePuedaObtenerUnaListaOrdenadaPorNombre() throws NoExisteLaGeneracionException {
		Empresa empresa = new Empresa("Aerolineas Argentinas");
		
		//Obtener generacion de la empresa
		Generacion g1 = empresa.buscarGeneracionPorID(1);
		Generacion g2 = empresa.buscarGeneracionPorID(2);
		Generacion g3 = empresa.buscarGeneracionPorID(3);
		
		Empleado empleado1 = new Empleado(123, "Maggie Simpson", LocalDate.of(2008, 11, 24), Rol.PILOTO, g1);
		Empleado empleado2 = new Empleado(212, "Homer Simpson", LocalDate.of(2012, 9, 12), Rol.AZAFATA, g2);
		Empleado empleado3 = new Empleado(333, "Marge Simpson", LocalDate.of(2010, 4, 2), Rol.PILOTO, g3);
		Empleado empleado4 = new Empleado(441, "Lisa Simpson", LocalDate.of(2003, 11, 22), Rol.AZAFATA, g1);
		Empleado empleado5 = new Empleado(15, "Bart Simpson", LocalDate.of(2015, 8, 20), Rol.PILOTO, g3);
		Empleado empleado6 = new Empleado(15, "Bart Simpson", LocalDate.of(2015, 8, 20), Rol.PILOTO, g3);
		
		empresa.agregarEmpleado(empleado1);
		empresa.agregarEmpleado(empleado2);
		empresa.agregarEmpleado(empleado3);
		empresa.agregarEmpleado(empleado4);
		empresa.agregarEmpleado(empleado5);
		empresa.agregarEmpleado(empleado6);
		
		Set<Empleado> empleadosOrdenados =  empresa.obtenerEmpleadosOrdenadosPorNombre();
		
		for (Empleado empleado : empleadosOrdenados) {
			System.out.println(empleado.getNombre() + " " + empleado.getId());
		}
	}
	
	@Test
	public void obtenerUnaLista() {
		
	}
}
