package ar.unlam.edu.pb2;

import java.time.LocalDate;

public class Empleado  implements Comparable<Empleado>{
	private Integer id;
	private LocalDate fechaIngreso;
	private String nombre;
	private Rol rol;
	private Generacion generacion;
	
	public Empleado(Integer id, String nombre, LocalDate fechaIngreso, Rol rol,Generacion generacion) {
		//super();
		this.id = id;
		this.nombre = nombre;
		this.fechaIngreso = fechaIngreso;
		this.rol = rol;
		this.generacion = generacion;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public Rol getRol() {
		return rol;
	}

	public void setRol(Rol rol) {
		this.rol = rol;
	}

	public Generacion getGeneracion() {
		return generacion;
	}

	public void setGeneracion(Generacion generacion) {
		this.generacion = generacion;
	}

	@Override
	public int compareTo(Empleado o) {
		return this.id.compareTo(o.id);
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Empleado other = (Empleado) obj;
		if (id == null) {
			if (other.id != null)
				return false;
		} else if (!id.equals(other.id))
			return false;
		return true;
	}
	
	
}
