package ar.unlam.edu.pb2;

public enum Rol {
	AZAFATA, PILOTO;
}
