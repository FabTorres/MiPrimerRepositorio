package ar.unlam.edu.pb2;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

public class Empresa {
	private String nombre;
	private List<Empleado> empleados;
	private List<Generacion> generaciones;
	private Rol rol;
	
	public Empresa(String nombre) {
		//super();
		this.nombre = nombre;
		this.empleados = new ArrayList<>();
		this.generaciones = this.crearGeneraciones();
	}
	
	public String getNombre() {
		return nombre;
	}
	
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	public List<Empleado> getEmpleados() {
		return empleados;
	}
	
	public void setEmpleados(List<Empleado> empleados) {
		this.empleados = empleados;
	}
	
	public List<Generacion> getGeneraciones() {
		return generaciones;
	}
	
	public void setGeneraciones(List<Generacion> generaciones) {
		this.generaciones = generaciones;
	}
	
	public void agregarEmpleado(Empleado empleado) {
		this.empleados.add(empleado);
	}
	
	public Integer cantidadEmpleados() {
		return this.empleados.size();
	}
	
	private ArrayList<Generacion> crearGeneraciones() {
		ArrayList<Generacion> generaciones = new ArrayList<>();
		generaciones.add(new Generacion(1, "G1"));
		generaciones.add(new Generacion(2, "G2"));
		generaciones.add(new Generacion(3, "G3"));
		return generaciones;
	}
	
	public Generacion buscarGeneracionPorID (Integer id) throws NoExisteLaGeneracionException {
		for (Generacion generacion : generaciones) {
			if (generacion.getId() == id) {
				return generacion;
			}
		}
		throw new NoExisteLaGeneracionException("No se encuentra esta generacion");
	}

	public Set<Empleado> obtenerEmpleadosOrdenadosPorId() {
		Set<Empleado> empleadosOrdenados = new TreeSet<>();
		empleadosOrdenados.addAll(this.empleados);
		
		return empleadosOrdenados;
	}
	
	public Set<Empleado> obtenerEmpleadosOrdenadosPorNombre() {
		Set<Empleado> empleadosOrdenados = new TreeSet<>(new OrdenEmpleadoPorNombre());
		empleadosOrdenados.addAll(this.empleados);
		
		return empleadosOrdenados;
	}
	
	public Map<Generacion, List<Empleado>> obtenerEmpleadosOrdenadorPorGeneracion () {
		Map<Generacion, List<Empleado>> empleadosOrdenadosPorGeneracion = new TreeMap<>();
		for (Generacion generacion : generaciones) {
			List <Empleado> listaEmpleados = obtenerListaEmpleadosPorGeneracion(generacion);
			empleadosOrdenadosPorGeneracion.put(generacion, listaEmpleados);
		}
		return empleadosOrdenadosPorGeneracion;
	}

	private List<Empleado> obtenerListaEmpleadosPorGeneracion(Generacion g) {
		List <Empleado> empleadosDeLaGeneracion = new ArrayList<>();
		for (Empleado e : empleados) {
			if (e.getGeneracion().equals(g)) {
				
			}
		}
		return empleadosDeLaGeneracion;
	}
}
