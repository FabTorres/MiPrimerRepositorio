package ar.unlam.edu.pb2;

public class NoExisteLaGeneracionException extends Exception {
	private String mensaje;

	public NoExisteLaGeneracionException(String mensaje) {
		this.mensaje = mensaje;
	}
	
	
}
